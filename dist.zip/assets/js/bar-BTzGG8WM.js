const s="/assets/png/bar-D8iUdd1u.png";export{s as b};
