const s="/assets/jpg/kedoclaw%E4%B8%80%E4%BD%93%E6%9C%BA%E7%99%BD-d1m1P0vm.jpg";export{s as p};
