import{s}from"./index-RW-S9KrD.js";const o=o=>s.post("/VersionCheck/CheckVersion",o),e="/assets/jpg/wx-Cdo6Mml_.jpg";export{o as g,e as w};
