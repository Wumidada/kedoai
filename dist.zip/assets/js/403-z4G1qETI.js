const s="/assets/svg/403-CaGap3SY.svg";export{s as _};
