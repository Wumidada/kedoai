const t="/assets/png/default_template-Cp9_wIj6.png";export{t as d};
