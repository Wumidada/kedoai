const o="/assets/png/logo-kedo-B28F61mG.png";export{o as _};
